﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finalProject
{
    public partial class LottoMAX : Form
    {
        public LottoMAX()
        {
            InitializeComponent();
        }

        //path to file - only works with the full path
        string dir = @".\files\"; //".\Files\LottoNbrs.txt";

        //Global variables
        DateTime openDate = DateTime.Now; // Time stamp when the form is loaded

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            // creates a new text file
            FileStream addNumbers = new FileStream(dir + "LottoNbrs.txt", FileMode.Append, FileAccess.Write);
            StreamWriter writeMax = new StreamWriter(addNumbers);

            List<int> printList = new List<int>(); // list to store the values to be printed
            int[] uniqueNumbers = new int[7]; // list to store the generated numbers
            int[] maxArray = new int[8]; // array to store the Lotto Max numbers
            int[] txtArray = new int[7]; // array to store the numbers to be printed
            Random random = new Random(); // random number generator
            int bonus;
            string txtList;

            txtNumbers.Clear(); // clears the field before the numbers are displayed

            for (int i = 0; i < 7; i++) // sequence of unique numbers
            {
                int randomNumber = random.Next(0, 9);
                if (uniqueNumbers.Contains(randomNumber) == false)
                {
                    uniqueNumbers[i] = randomNumber;// += uniqueNumbers;
                }
                else { i--; } // reduce the count if the generated number has alredy been sent to the list
            }
            string uniqueSequence = string.Join(" ", uniqueNumbers);
            lbExtra.Text = uniqueSequence;

            for (int i = 0; i < maxArray.Length; i++) // sequence of unique Lotto Max numbers
            {
                int randomNumber = random.Next(1, 50); // number range for Lotto Max
                if (maxArray.Contains(randomNumber) == false)
                {
                    maxArray[i] = randomNumber;
                    txtNumbers.Text += randomNumber;
                    txtNumbers.AppendText(Environment.NewLine);
                    
                }
                
                else { i--; } // reduce the count if the generated number has alredy been sent to the list

            }

            // loop to remove the bonus number and display it separate from the other numbers in the text file
            //in the formatted style
            for (int i = 0; i < maxArray.Length - 1; i++) 
            {
                txtArray[i] = maxArray[i];
            }

            printList.AddRange(txtArray);
            txtList = string.Join(",", printList);
            bonus = maxArray.Last();

            writeMax.Write("Max, " + openDate + ", " + txtList + " Bonus " + bonus + "\n"); // print the data
                                                                                            // into the file
            writeMax.Close(); // close the write stream for the text file
            addNumbers.Close(); // close the FileStream
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to quit this application?", "Exit?", MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                this.Close();
            }
        }

        private void btnReadFile_Click(object sender, EventArgs e)
        {
            FileStream readFile = new FileStream(dir + "LottoNbrs.txt", FileMode.OpenOrCreate, FileAccess.Read);
            StreamReader readMax = new StreamReader(readFile);
            string display = "";

            while (readMax.Peek() != -1) // read the file until there are no characters left
            {

                string conv = readMax.ReadLine();
                display += conv + "\n";
            }
            MessageBox.Show(display, "Lotto Max - Daniel");
            readMax.Close();
            readFile.Close();
        }
    }
}
