﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using System.Text.RegularExpressions; // call Regular Expressions methods
using static System.Net.Mime.MediaTypeNames;
using System.IO;

namespace finalProject
{
    public partial class MoneyEx : Form
    {
        public MoneyEx()
        {
            InitializeComponent();
        }

        //path to file
        string dir = @".\files\";

        //Global variables

        DateTime openDate = DateTime.Now; // Time stamp when the form is loaded
        string fromCurrency; // from currency
        string toCurrency; // To currency

        private void btnConvert_Click(object sender, EventArgs e)
        {
            // creates a new text file
            FileStream addConv = new FileStream(dir + "MoneyEx.txt", FileMode.Append, FileAccess.Write);
            StreamWriter writeConv = new StreamWriter(addConv);

            try
            {
                //variables
                double convRate;
                string moneyPattern = @"^[0-9]+(.)?[0-9]{0,2}$";
                bool validPattern = Regex.IsMatch(textBox1.Text.Trim(), moneyPattern);

                //conversion rates obtained on 18/03/2023 using the XE conversion tool
                //available at https://www.xe.com/currencyconverteroogle 
                double cadToCad = 1; //CAD -> CAD
                double cadToUsd = 0.72742981; // CAD -> USD
                double cadToEur = 0.67853611; // CAD -> EUR
                double cadToGbp = 0.59723802; // CAD -> GBP
                double cadToBrl = 3.84395473; // CAD -> BRL



                if (validPattern == true)
                {
                    if (radioBtnFromCAD.Checked == true && radioBtnToCAD.Checked == true)
                    {
                        convRate = cadToCad;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromCAD.Text;
                        toCurrency = radioBtnToCAD.Text;
                    }
                    else if (radioBtnFromCAD.Checked == true && radioBtnToUSD.Checked == true)
                    {
                        convRate = cadToUsd;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromCAD.Text;
                        toCurrency = radioBtnToUSD.Text;
                    }
                    else if (radioBtnFromCAD.Checked == true && radioBtnToEUR.Checked == true)
                    {
                        convRate = cadToEur;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromCAD.Text;
                        toCurrency = radioBtnToEUR.Text;
                    }
                    else if (radioBtnFromCAD.Checked == true && radioBtnToGBP.Checked == true)
                    {
                        convRate = cadToGbp;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromCAD.Text;
                        toCurrency = radioBtnToGBP.Text;
                    }
                    else if (radioBtnFromCAD.Checked == true && radioBtnToBRL.Checked == true)
                    {
                        convRate = cadToBrl;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromCAD.Text;
                        toCurrency = radioBtnToBRL.Text;
                    }
                    else if (radioBtnFromUSD.Checked == true && radioBtnToCAD.Checked == true)
                    {
                        convRate = 1 / cadToUsd;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromUSD.Text;
                        toCurrency = radioBtnToCAD.Text;
                    }
                    else if (radioBtnFromUSD.Checked == true && radioBtnToUSD.Checked == true)
                    {
                        convRate = (1 / cadToUsd) * cadToUsd;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromUSD.Text;
                        toCurrency = radioBtnToUSD.Text;
                    }
                    else if (radioBtnFromUSD.Checked == true && radioBtnToEUR.Checked == true)
                    {
                        convRate = (1 / cadToUsd) * cadToEur;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromUSD.Text;
                        toCurrency = radioBtnToEUR.Text;
                    }
                    else if (radioBtnFromUSD.Checked == true && radioBtnToGBP.Checked == true)
                    {
                        convRate = (1 / cadToUsd) * cadToGbp;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromUSD.Text;
                        toCurrency = radioBtnToGBP.Text;
                    }
                    else if (radioBtnFromUSD.Checked == true && radioBtnToBRL.Checked == true)
                    {
                        convRate = (1 / cadToUsd) * cadToBrl;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromUSD.Text;
                        toCurrency = radioBtnToBRL.Text;
                    }
                    else if (radioBtnFromEUR.Checked == true && radioBtnToCAD.Checked == true)
                    {
                        convRate = (1 / cadToEur) * cadToCad;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromEUR.Text;
                        toCurrency = radioBtnToCAD.Text;
                    }
                    else if (radioBtnFromEUR.Checked == true && radioBtnToUSD.Checked == true)
                    {
                        convRate = (1 / cadToEur) * cadToUsd;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromEUR.Text;
                        toCurrency = radioBtnToUSD.Text;
                    }
                    else if (radioBtnFromEUR.Checked == true && radioBtnToEUR.Checked == true)
                    {
                        convRate = (1 / cadToEur) * cadToEur;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromEUR.Text;
                        toCurrency = radioBtnToEUR.Text;
                    }
                    else if (radioBtnFromEUR.Checked == true && radioBtnToGBP.Checked == true)
                    {
                        convRate = (1 / cadToEur) * cadToGbp;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromEUR.Text;
                        toCurrency = radioBtnToGBP.Text;
                    }
                    else if (radioBtnFromEUR.Checked == true && radioBtnToBRL.Checked == true)
                    {
                        convRate = (1 / cadToEur) * cadToBrl;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromEUR.Text;
                        toCurrency = radioBtnToBRL.Text;
                    }
                    else if (radioBtnFromGBP.Checked == true && radioBtnToCAD.Checked == true)
                    {
                        convRate = (1 / cadToGbp) * cadToCad;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromGBP.Text;
                        toCurrency = radioBtnToCAD.Text;
                    }
                    else if (radioBtnFromGBP.Checked == true && radioBtnToUSD.Checked == true)
                    {
                        convRate = (1 / cadToGbp) * cadToUsd;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromGBP.Text;
                        toCurrency = radioBtnToUSD.Text;
                    }
                    else if (radioBtnFromGBP.Checked == true && radioBtnToEUR.Checked == true)
                    {
                        convRate = (1 / cadToGbp) * cadToEur;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromGBP.Text;
                        toCurrency = radioBtnToEUR.Text;
                    }
                    else if (radioBtnFromGBP.Checked == true && radioBtnToGBP.Checked == true)
                    {
                        convRate = (1 / cadToGbp) * cadToGbp;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromGBP.Text;
                        toCurrency = radioBtnToGBP.Text;
                    }
                    else if (radioBtnFromGBP.Checked == true && radioBtnToBRL.Checked == true)
                    {
                        convRate = (1 / cadToGbp) * cadToBrl;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromGBP.Text;
                        toCurrency = radioBtnToBRL.Text;
                    }
                    else if (radioBtnFromBRL.Checked == true && radioBtnToCAD.Checked == true)
                    {
                        convRate = (1 / cadToBrl) * cadToCad;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromBRL.Text;
                        toCurrency = radioBtnToCAD.Text;
                    }
                    else if (radioBtnFromBRL.Checked == true && radioBtnToUSD.Checked == true)
                    {
                        convRate = (1 / cadToBrl) * cadToUsd;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromBRL.Text;
                        toCurrency = radioBtnToUSD.Text;
                    }
                    else if (radioBtnFromBRL.Checked == true && radioBtnToEUR.Checked == true)
                    {
                        convRate = (1 / cadToBrl) * cadToEur;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromBRL.Text;
                        toCurrency = radioBtnToEUR.Text;
                    }
                    else if (radioBtnFromBRL.Checked == true && radioBtnToGBP.Checked == true)
                    {
                        convRate = (1 / cadToBrl) * cadToGbp;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromBRL.Text;
                        toCurrency = radioBtnToGBP.Text;
                    }
                    else if (radioBtnFromBRL.Checked == true && radioBtnToBRL.Checked == true)
                    {
                        convRate = (1 / cadToBrl) * cadToBrl;
                        textBox2.Text = Convert.ToString(convRate * Convert.ToDouble(textBox1.Text));
                        fromCurrency = radioBtnFromBRL.Text;
                        toCurrency = radioBtnToBRL.Text;
                    }

                    //write each conversion operation
                    double formatted = Math.Round(Convert.ToDouble(textBox2.Text));
                    writeConv.Write(textBox1.Text.Trim() + " " + fromCurrency + " = " + formatted
                        + " " + toCurrency + "; " + openDate + "\n");


                }
                else
                {
                    MessageBox.Show("Format is not valid");
                    textBox1.Focus(); // places cursor back to textBox1
                    textBox1.Clear();
                    textBox2.Clear();
                }

                writeConv.Close(); // close the write stream for the text file
                addConv.Close(); // close the FileStream

            }

            catch (IOException)
            {
                MessageBox.Show("Please enter a number", "Error", MessageBoxButtons.OK).ToString();
                textBox1.Clear();
                textBox1.Focus();
            }
            
        
        
    }
        private void MoneyEx_Load(object sender, EventArgs e)
        {
            DateTime openDate = DateTime.Now; // Time stamp when the form is loaded
            if (Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            TimeSpan session;

            if (MessageBox.Show("Do you want to quit the application Money Exchange?", "Exit?", MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                DateTime closeDate = DateTime.Now;
                session = openDate.Subtract(closeDate);
                MessageBox.Show("You have used the Money Exchange App for " + session.Duration().Minutes + " min and " + session.Duration().Seconds + "s");
                this.Close();
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream readFile = new FileStream(dir + "MoneyEx.txt", FileMode.OpenOrCreate, FileAccess.Read);
                StreamReader readConv = new StreamReader(readFile);
                string format;
                string display = "From\t To\t When\n";

                while (readConv.Peek() != -1) // read the file until there are no characters left
                {

                    string conv = readConv.ReadLine();
                    string[] columns = conv.Split('='); // divisor de decimal em português. Posso mudar pra ;?
                    format = columns[0];
                    string[] date = columns[1].Split(';');// + "\n";
                    display += format + "\t" + date[0] + "\t" + date[1] + "\n";
                }
                MessageBox.Show(display, "List of Conversions - Daniel");
                readConv.Close(); // close the Stream Writer
                readFile.Close(); // close the FileStream
            }

            catch (IOException ex)
            {
                MessageBox.Show("IO Exception\n" + ex.Message);
            }
            
        }
    }
}
