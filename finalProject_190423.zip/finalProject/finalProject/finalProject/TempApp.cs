﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finalProject
{
    public partial class TempApp : Form
    {
        public TempApp()
        {
            InitializeComponent();
        }

        //path to file
        string dir = @".\files\";

        //Global variables

        DateTime openDate = DateTime.Now; // Time stamp when the form is loaded
        string fromTemp; // from temperature
        string toTemp; // To temperature
        double celsius;
        double fahrenheit;

        private void btnConvertTemp_Click(object sender, EventArgs e)
        {

            // creates a new text file
            FileStream addConv = new FileStream(dir+"TempConv.txt", FileMode.Append, FileAccess.Write);
            StreamWriter writeConv = new StreamWriter(addConv);

            try
            {
                //variables

                string tempPattern = @"^((-)?\d+|\d+\.\d+)$";
                bool validPattern = System.Text.RegularExpressions.Regex.IsMatch(textBox1.Text.Trim(), tempPattern);


                if (validPattern == true)
                {
                    if (rdCtoF.Checked == true)
                    {
                        try
                        {
                            celsius = Convert.ToDouble(textBox1.Text);
                            fromTemp = "C";
                            toTemp = "F";
                        }
                        catch (Exception ex) {
                            MessageBox.Show("error" + ex.Message);
                        }
                               

                        if (celsius <= -273.15)
                        {
                            MessageBox.Show("Please insert a value higher than -273.15 °C (absolute zero)", "Error", MessageBoxButtons.OK);
                            textBox1.Text = "0";
                            lbResult.Text = "";
                            textBox1.Focus();
                            writeConv.Close(); // close the write stream for the text file
                            addConv.Close(); // close the FileStream
                            return;
                        }
                        else
                        {
                            if (celsius == 100)
                            {
                                lbMessage.Text = "Water Boils";
                                textBox1.ForeColor = Color.Red;
                                lbResult.ForeColor = Color.Red;
                                lbMessage.ForeColor = Color.Red;
                            }
                            else if (celsius == 40)
                            {
                                lbMessage.Text = "Hot Bath";
                                textBox1.ForeColor = Color.Red;
                                lbResult.ForeColor = Color.Red;
                                lbMessage.ForeColor = Color.Red;
                            }
                            else if (celsius == 37)
                            {
                                lbMessage.Text = "Body Temperature";
                                textBox1.ForeColor = Color.Green;
                                lbResult.ForeColor = Color.Green;
                                lbMessage.ForeColor = Color.Green;
                            }
                            else if (celsius == 30)
                            {
                                lbMessage.Text = "Beach Weather";
                                textBox1.ForeColor = Color.Green;
                                lbResult.ForeColor = Color.Green;
                                lbMessage.ForeColor = Color.Green;
                            }
                            else if (celsius == 21)
                            {
                                lbMessage.Text = "Room Temperature";
                                textBox1.ForeColor = Color.Green;
                                lbResult.ForeColor = Color.Green;
                                lbMessage.ForeColor = Color.Green;
                            }
                            else if (celsius == 10)
                            {
                                lbMessage.Text = "Cool Day";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else if (celsius == 0)
                            {
                                lbMessage.Text = "Freezing Point of Water";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else if (celsius == -18)
                            {
                                lbMessage.Text = "Very Cold Day";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else if (celsius == -40)
                            {
                                lbMessage.Text = "Extremely Cold Day (and the same number!)";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else
                            {
                                lbMessage.Text = "";
                                textBox1.ForeColor = Color.Black;
                                lbResult.ForeColor = Color.Black;
                                lbMessage.ForeColor = Color.Black;
                            }
                            lbResult.Text = Convert.ToString(Math.Round(celsius * 9 / 5 + 32,2)); // Rounds the display to 2 decimal points

                        }


                    }
                    else if (rdFtoC.Checked == true)
                    {
                        try
                        {
                            fahrenheit = Convert.ToDouble(textBox1.Text);
                            fromTemp = "F";
                            toTemp = "C";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("error" + ex.Message);
                        }

                        if (fahrenheit <= -459.67)
                        {
                            MessageBox.Show("Please insert a value higher than -459,67F (absolute zero)", "Error", MessageBoxButtons.OK);
                            textBox1.Text = "0";
                            lbResult.Text = "";
                            textBox1.Focus();
                            writeConv.Close(); // close the write stream for the text file
                            addConv.Close(); // close the FileStream
                            return;

                        }
                        else
                        {
                            if (fahrenheit == 212)
                            {
                                lbMessage.Text = "Water Boils";
                                textBox1.ForeColor = Color.Red;
                                lbResult.ForeColor = Color.Red;
                                lbMessage.ForeColor = Color.Red;
                            }
                            else if (fahrenheit == 104)
                            {
                                lbMessage.Text = "Hot Bath";
                                textBox1.ForeColor = Color.Red;
                                lbResult.ForeColor = Color.Red;
                                lbMessage.ForeColor = Color.Red;
                            }
                            else if (fahrenheit == 98.6)
                            {
                                lbMessage.Text = "Body Temperature";
                                textBox1.ForeColor = Color.Green;
                                lbResult.ForeColor = Color.Green;
                                lbMessage.ForeColor = Color.Green;
                            }
                            else if (fahrenheit == 86)
                            {
                                lbMessage.Text = "Beach Weather";
                                textBox1.ForeColor = Color.Green;
                                lbResult.ForeColor = Color.Green;
                                lbMessage.ForeColor = Color.Green;
                            }
                            else if (fahrenheit == 70)
                            {
                                lbMessage.Text = "Room Temperature";
                                textBox1.ForeColor = Color.Green;
                                lbResult.ForeColor = Color.Green;
                                lbMessage.ForeColor = Color.Green;
                            }
                            else if (fahrenheit == 50)
                            {
                                lbMessage.Text = "Cool Day";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else if (fahrenheit == 32)
                            {
                                lbMessage.Text = "Freezing Point of Water";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else if (fahrenheit == 0)
                            {
                                lbMessage.Text = "Very Cold Day";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else if (fahrenheit == -40)
                            {
                                lbMessage.Text = "Extremely Cold Day (and the same number!)";
                                textBox1.ForeColor = Color.Blue;
                                lbResult.ForeColor = Color.Blue;
                                lbMessage.ForeColor = Color.Blue;
                            }
                            else
                            {
                                lbMessage.Text = "";
                                textBox1.ForeColor = Color.Black;
                                lbResult.ForeColor = Color.Black;
                                lbMessage.ForeColor = Color.Black;
                            }
                            lbResult.Text = Convert.ToString(Math.Round((fahrenheit - 32) * 5 / 9,2)); //Rounds display to 2 decimal points
                        }
                    }

                    //write each conversion operation
                    double formatted = Math.Round(Convert.ToDouble(lbResult.Text));
                    writeConv.Write(textBox1.Text.Trim() + " " + fromTemp + " = " + formatted
                        + " " + toTemp + ", " + openDate + " " + lbMessage.Text + "\n");

                    writeConv.Close(); // close the write stream for the text file
                    addConv.Close(); // close the FileStream

                }
                else
                {
                    MessageBox.Show("Please enter a value");
                    textBox1.Focus(); // places cursor back to textBox1
                    textBox1.Text = "";
                    lbResult.Text = "";
                    writeConv.Close(); // close the write stream for the text file
                    addConv.Close(); // close the FileStream
                    return;

                }

            }

            catch (IOException)
            {
                if (MessageBox.Show("Please enter a valid number", "Error", MessageBoxButtons.OK).ToString() == "OK")
                {
                    textBox1.Clear();
                    textBox1.Focus();
                }

            }

        }

        private void btnExitTemp_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to quit the application TempApp?", "Exit?", MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                this.Close();
            }
        }

        private void rdCtoF_CheckedChanged(object sender, EventArgs e)
        {
            lbInput.Text = "C";
            lbOutput.Text = "F";
        }

        private void rdFtoC_CheckedChanged(object sender, EventArgs e)
        {
            lbInput.Text = "F";
            lbOutput.Text = "C";
        }

        private void btnReadTemp_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream readFile = new FileStream(dir+"TempConv.txt", FileMode.OpenOrCreate, FileAccess.Read);
                StreamReader readConv = new StreamReader(readFile);
                string format;
                string display = "From\t To\t When\t\t Message\n";

                while (readConv.Peek() != -1) // read the file until there are no characters left
                {

                    string conv = readConv.ReadLine();
                    string[] columns = conv.Split('='); // splits the line in the "=" sign
                    format = columns[0];
                    string[] date = columns[1].Split(','); // splits the remainder of the file in the "," character
                    string message = date[1].Trim();
                    display += format + "\t" + date[0] + "\t" + date[1] + "\n";
                }
                MessageBox.Show(display, "List of Conversions - Daniel");
                readConv.Close(); // close the Stream Writer
                readFile.Close(); // close the FileStream
                                 
            }

            catch (IOException ex)
            {
                MessageBox.Show("IO Exception\n" + ex.Message);
            }
        }

        private void TempApp_Load(object sender, EventArgs e)
        {
            if(Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
        }
    }
}
