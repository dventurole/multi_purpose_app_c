﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace finalProject
{
    public partial class IPval : Form
    {
        public IPval()
        {
            InitializeComponent();
        }

        //path to file
        string dir = @".\files\";

        DateTime openDate = DateTime.Now; // Time stamp when the form is loaded

        private void IPval_Load(object sender, EventArgs e)
        {
            
            if (Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
            label2.Text = Convert.ToString(DateTime.Today.ToLongDateString());
        }

        private void btnExitIP_Click(object sender, EventArgs e)
        {
            TimeSpan session;

            if (MessageBox.Show("Do you want to quit the application IP Validator?", "Exit?", MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                DateTime closeDate = DateTime.Now;
                session = openDate.Subtract(closeDate);
                MessageBox.Show("You have used the IP Validator for " + session.Duration().Minutes + " min and " + session.Duration().Seconds + "s");
                this.Close();
            }
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            // creates a new text file
            FileStream addVal = new FileStream(dir + "IPval.txt", FileMode.Append, FileAccess.Write);
            BinaryWriter writeVal = new BinaryWriter(addVal);

            try
            {
                string ipPattern = @"^(25[0-5]|2[0-4]\d|[0-1]?\d?\d)(\.(25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}$";
                bool validIP = Regex.IsMatch(textBox1.Text.Trim(), ipPattern);

                if (validIP == true)
                {
                    MessageBox.Show(textBox1.Text.Trim() + "\nThe IP is correct", "Valid IP");
                    //write each conversion operation
                    writeVal.Write(textBox1.Text + " Verified on " + label2.Text);


                    writeVal.Close(); // close the binary stream for the text file
                    addVal.Close(); // close the FileStream
                }
                else
                {

                    MessageBox.Show(textBox1.Text + "\nThe IP must have 4 bytes\n" +
                    "integer number between 0 and 255\n" + "separated by a dot (255.255.255.255)", "Error",
                    MessageBoxButtons.OK).ToString();
                    textBox1.Clear();
                    textBox1.Focus();
                    writeVal.Close(); // close the binary stream for the text file
                    addVal.Close();
                }

            }


            catch (Exception)
            {
                MessageBox.Show(textBox1.Text + "\nThe IP must have 4 bytes\n" +
                    "integer number between 0 and 255\n" + "separated by a dot (255.255.255.255)", "Error",
                    MessageBoxButtons.OK).ToString();
                textBox1.Clear();
                textBox1.Focus();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Focus();
        }
    }
}
