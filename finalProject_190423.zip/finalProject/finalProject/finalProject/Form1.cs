﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finalProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //path to file - only works with the full path
        string dir = @".\files\";

        private void btnMax_Click(object sender, EventArgs e)
        {
            LottoMAX obj = new LottoMAX();
            obj.ShowDialog();
        }

        private void btnMoneyEx_Click(object sender, EventArgs e)
        {
            MoneyEx obj = new MoneyEx();
            obj.ShowDialog();

        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            Lotto649 obj = new Lotto649();
            obj.ShowDialog();
        }

        private void btnTemp_Click(object sender, EventArgs e)
        {
            TempApp obj = new TempApp();
            obj.ShowDialog();

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Calc obj = new Calc();
            obj.ShowDialog();
        }

        private void btnIPval_Click(object sender, EventArgs e)
        {
            IPval obj = new IPval();
            obj.ShowDialog();
        }

        private void btnExitForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
        }
    }
}
