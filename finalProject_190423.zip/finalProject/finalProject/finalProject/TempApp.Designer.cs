﻿namespace finalProject
{
    partial class TempApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExitTemp = new System.Windows.Forms.Button();
            this.btnReadTemp = new System.Windows.Forms.Button();
            this.btnConvertTemp = new System.Windows.Forms.Button();
            this.rdCtoF = new System.Windows.Forms.RadioButton();
            this.rdFtoC = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbInput = new System.Windows.Forms.Label();
            this.lbOutput = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbResult = new System.Windows.Forms.Label();
            this.lbMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExitTemp
            // 
            this.btnExitTemp.Location = new System.Drawing.Point(375, 411);
            this.btnExitTemp.Name = "btnExitTemp";
            this.btnExitTemp.Size = new System.Drawing.Size(103, 43);
            this.btnExitTemp.TabIndex = 16;
            this.btnExitTemp.Text = "E&xit";
            this.btnExitTemp.UseVisualStyleBackColor = true;
            this.btnExitTemp.Click += new System.EventHandler(this.btnExitTemp_Click);
            // 
            // btnReadTemp
            // 
            this.btnReadTemp.Location = new System.Drawing.Point(243, 411);
            this.btnReadTemp.Name = "btnReadTemp";
            this.btnReadTemp.Size = new System.Drawing.Size(103, 43);
            this.btnReadTemp.TabIndex = 15;
            this.btnReadTemp.Text = "&Read File";
            this.btnReadTemp.UseVisualStyleBackColor = true;
            this.btnReadTemp.Click += new System.EventHandler(this.btnReadTemp_Click);
            // 
            // btnConvertTemp
            // 
            this.btnConvertTemp.Location = new System.Drawing.Point(28, 411);
            this.btnConvertTemp.Name = "btnConvertTemp";
            this.btnConvertTemp.Size = new System.Drawing.Size(186, 43);
            this.btnConvertTemp.TabIndex = 14;
            this.btnConvertTemp.Text = "&Convert";
            this.btnConvertTemp.UseVisualStyleBackColor = true;
            this.btnConvertTemp.Click += new System.EventHandler(this.btnConvertTemp_Click);
            // 
            // rdCtoF
            // 
            this.rdCtoF.AutoSize = true;
            this.rdCtoF.Checked = true;
            this.rdCtoF.Location = new System.Drawing.Point(193, 42);
            this.rdCtoF.Name = "rdCtoF";
            this.rdCtoF.Size = new System.Drawing.Size(113, 24);
            this.rdCtoF.TabIndex = 17;
            this.rdCtoF.TabStop = true;
            this.rdCtoF.Text = "from C to F";
            this.rdCtoF.UseVisualStyleBackColor = true;
            this.rdCtoF.CheckedChanged += new System.EventHandler(this.rdCtoF_CheckedChanged);
            // 
            // rdFtoC
            // 
            this.rdFtoC.AutoSize = true;
            this.rdFtoC.Location = new System.Drawing.Point(193, 84);
            this.rdFtoC.Name = "rdFtoC";
            this.rdFtoC.Size = new System.Drawing.Size(113, 24);
            this.rdFtoC.TabIndex = 18;
            this.rdFtoC.Text = "from F to C";
            this.rdFtoC.UseVisualStyleBackColor = true;
            this.rdFtoC.CheckedChanged += new System.EventHandler(this.rdFtoC_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(28, 164);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(164, 26);
            this.textBox1.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(235, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 20);
            this.label1.TabIndex = 25;
            this.label1.Text = "to";
            // 
            // lbInput
            // 
            this.lbInput.AutoSize = true;
            this.lbInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbInput.Location = new System.Drawing.Point(88, 207);
            this.lbInput.Name = "lbInput";
            this.lbInput.Size = new System.Drawing.Size(21, 20);
            this.lbInput.TabIndex = 26;
            this.lbInput.Text = "C";
            // 
            // lbOutput
            // 
            this.lbOutput.AutoSize = true;
            this.lbOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOutput.Location = new System.Drawing.Point(386, 207);
            this.lbOutput.Name = "lbOutput";
            this.lbOutput.Size = new System.Drawing.Size(20, 20);
            this.lbOutput.TabIndex = 27;
            this.lbOutput.Text = "F";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 20);
            this.label4.TabIndex = 29;
            this.label4.Text = "Message:";
            // 
            // lbResult
            // 
            this.lbResult.AutoSize = true;
            this.lbResult.Location = new System.Drawing.Point(371, 170);
            this.lbResult.Name = "lbResult";
            this.lbResult.Size = new System.Drawing.Size(0, 20);
            this.lbResult.TabIndex = 30;
            this.lbResult.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbMessage
            // 
            this.lbMessage.AutoSize = true;
            this.lbMessage.Location = new System.Drawing.Point(28, 287);
            this.lbMessage.Name = "lbMessage";
            this.lbMessage.Size = new System.Drawing.Size(0, 20);
            this.lbMessage.TabIndex = 31;
            // 
            // TempApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(509, 466);
            this.Controls.Add(this.lbMessage);
            this.Controls.Add(this.lbResult);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbOutput);
            this.Controls.Add(this.lbInput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.rdFtoC);
            this.Controls.Add(this.rdCtoF);
            this.Controls.Add(this.btnExitTemp);
            this.Controls.Add(this.btnReadTemp);
            this.Controls.Add(this.btnConvertTemp);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TempApp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Temp App - Daniel";
            this.Load += new System.EventHandler(this.TempApp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExitTemp;
        private System.Windows.Forms.Button btnReadTemp;
        private System.Windows.Forms.Button btnConvertTemp;
        private System.Windows.Forms.RadioButton rdCtoF;
        private System.Windows.Forms.RadioButton rdFtoC;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbInput;
        private System.Windows.Forms.Label lbOutput;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbResult;
        private System.Windows.Forms.Label lbMessage;
    }
}