﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace finalProject
{
    
    public partial class Calc : Form
    {
        public static decimal Add(decimal num1, decimal num2)
        {
            return num1 + num2;
        }

        public static decimal Sub(decimal num1, decimal num2)
        {
            return num1 - num2;
        }

        public static decimal Mul(decimal num1, decimal num2)
        {
            return num1 * num2;
        }

        public static decimal Div(decimal num1, decimal num2)
        {
            return num1 / num2;
        }
        public Calc()
        {
            InitializeComponent();
        }

        //path to file
        string dir = @".\files\";

        //Global variables
        string op;
        decimal num1, num2, currentValue;


        private void btnEqual_Click(object sender, EventArgs e)
        {
            try
            {
                // creates a new text file
                FileStream addCalc = new FileStream(dir + "Calculator.txt", FileMode.Append, FileAccess.Write);
                StreamWriter writeCalc = new StreamWriter(addCalc);

                num2 = Convert.ToDecimal(txtDisplay.Text);
                
                switch (op)
                {
                    case "+":
                        currentValue = Add(num1, num2);
                        txtDisplay.Text = currentValue.ToString();
                        //write each conversion operation
                        writeCalc.Write(num1 + op + num2 + " = " + currentValue + "\n");
                        break;
                    case "-":
                        currentValue = Sub(num1, num2);
                        txtDisplay.Text = currentValue.ToString();
                        //write each conversion operation
                        writeCalc.Write(num1 + op + num2 + " = " + currentValue + "\n");
                        break;
                    case "*":
                        currentValue = Mul(num1, num2);
                        txtDisplay.Text = currentValue.ToString();
                        //write each conversion operation
                        writeCalc.Write(num1 + op + num2 + " = " + currentValue + "\n");
                        break;
                    case "/":
                        if (num2 == 0)
                        {
                            MessageBox.Show("You can't divide by zero", "Error");
                        }
                        else
                        {
                            currentValue = Div(num1, num2);
                            txtDisplay.Text = currentValue.ToString();
                            //write each conversion operation
                            writeCalc.Write(num1 + op + num2 + " = " + currentValue + "\n");
                        }
                        break;
                }

                writeCalc.Close(); // close the write stream for the text file
                addCalc.Close(); // close the FileStream
            }
            catch (IOException)
            {
                if (MessageBox.Show("Please enter a valid number", "Error", MessageBoxButtons.OK).ToString() == "OK")
                {
                    txtDisplay.Clear();
                    txtDisplay.Focus();
                }
            }

          


        }


        private void btn1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += "0";
        }

        private void btnDot_Click(object sender, EventArgs e)
        {
            txtDisplay.Text += ",";
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            op = "-";

            num1 = Convert.ToDecimal(txtDisplay.Text);
            txtDisplay.Text = Convert.ToString(num1);
            txtDisplay.Text = "";
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            op = "*";

            num1 = Convert.ToDecimal(txtDisplay.Text);
            txtDisplay.Text = Convert.ToString(num1);
            txtDisplay.Text = "";
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            op = "/";

            num1 = Convert.ToDecimal(txtDisplay.Text);
            txtDisplay.Text = Convert.ToString(num1);
            txtDisplay.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Calc_Load(object sender, EventArgs e)
        {

            txtDisplay.Text = "";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            num1 = ' ';
            num2 = ' ';
            txtDisplay.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            op = "+";
            num1 = Convert.ToDecimal(txtDisplay.Text);
            txtDisplay.Text = Convert.ToString(num1);
            txtDisplay.Text = "";

        }
    }
}
