﻿namespace finalProject
{
    partial class MoneyEx
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MoneyEx));
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.radioBtnFromBRL = new System.Windows.Forms.RadioButton();
            this.radioBtnFromGBP = new System.Windows.Forms.RadioButton();
            this.radioBtnFromEUR = new System.Windows.Forms.RadioButton();
            this.radioBtnFromUSD = new System.Windows.Forms.RadioButton();
            this.radioBtnFromCAD = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.radioBtnToBRL = new System.Windows.Forms.RadioButton();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.radioBtnToGBP = new System.Windows.Forms.RadioButton();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.radioBtnToEUR = new System.Windows.Forms.RadioButton();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.radioBtnToUSD = new System.Windows.Forms.RadioButton();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.radioBtnToCAD = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(375, 411);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(103, 43);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(243, 411);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(103, 43);
            this.btnRead.TabIndex = 12;
            this.btnRead.Text = "&Read File";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(28, 411);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(186, 43);
            this.btnConvert.TabIndex = 11;
            this.btnConvert.Text = "&Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.radioBtnFromBRL);
            this.groupBox1.Controls.Add(this.radioBtnFromGBP);
            this.groupBox1.Controls.Add(this.radioBtnFromEUR);
            this.groupBox1.Controls.Add(this.radioBtnFromUSD);
            this.groupBox1.Controls.Add(this.radioBtnFromCAD);
            this.groupBox1.Location = new System.Drawing.Point(28, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 283);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "From";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(90, 225);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(73, 44);
            this.pictureBox5.TabIndex = 23;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(90, 75);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(73, 44);
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(89, 175);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(73, 44);
            this.pictureBox4.TabIndex = 22;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(89, 125);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(73, 44);
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(89, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 44);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // radioBtnFromBRL
            // 
            this.radioBtnFromBRL.AutoSize = true;
            this.radioBtnFromBRL.Location = new System.Drawing.Point(15, 234);
            this.radioBtnFromBRL.Name = "radioBtnFromBRL";
            this.radioBtnFromBRL.Size = new System.Drawing.Size(66, 24);
            this.radioBtnFromBRL.TabIndex = 19;
            this.radioBtnFromBRL.TabStop = true;
            this.radioBtnFromBRL.Text = "BRL";
            this.radioBtnFromBRL.UseVisualStyleBackColor = true;
            // 
            // radioBtnFromGBP
            // 
            this.radioBtnFromGBP.AutoSize = true;
            this.radioBtnFromGBP.Location = new System.Drawing.Point(15, 186);
            this.radioBtnFromGBP.Name = "radioBtnFromGBP";
            this.radioBtnFromGBP.Size = new System.Drawing.Size(68, 24);
            this.radioBtnFromGBP.TabIndex = 18;
            this.radioBtnFromGBP.TabStop = true;
            this.radioBtnFromGBP.Text = "GBP";
            this.radioBtnFromGBP.UseVisualStyleBackColor = true;
            // 
            // radioBtnFromEUR
            // 
            this.radioBtnFromEUR.AutoSize = true;
            this.radioBtnFromEUR.Location = new System.Drawing.Point(15, 136);
            this.radioBtnFromEUR.Name = "radioBtnFromEUR";
            this.radioBtnFromEUR.Size = new System.Drawing.Size(69, 24);
            this.radioBtnFromEUR.TabIndex = 17;
            this.radioBtnFromEUR.TabStop = true;
            this.radioBtnFromEUR.Text = "EUR";
            this.radioBtnFromEUR.UseVisualStyleBackColor = true;
            // 
            // radioBtnFromUSD
            // 
            this.radioBtnFromUSD.AutoSize = true;
            this.radioBtnFromUSD.Location = new System.Drawing.Point(15, 86);
            this.radioBtnFromUSD.Name = "radioBtnFromUSD";
            this.radioBtnFromUSD.Size = new System.Drawing.Size(69, 24);
            this.radioBtnFromUSD.TabIndex = 16;
            this.radioBtnFromUSD.TabStop = true;
            this.radioBtnFromUSD.Text = "USD";
            this.radioBtnFromUSD.UseVisualStyleBackColor = true;
            // 
            // radioBtnFromCAD
            // 
            this.radioBtnFromCAD.AutoSize = true;
            this.radioBtnFromCAD.Checked = true;
            this.radioBtnFromCAD.Location = new System.Drawing.Point(15, 35);
            this.radioBtnFromCAD.Name = "radioBtnFromCAD";
            this.radioBtnFromCAD.Size = new System.Drawing.Size(68, 24);
            this.radioBtnFromCAD.TabIndex = 15;
            this.radioBtnFromCAD.TabStop = true;
            this.radioBtnFromCAD.Text = "CAD";
            this.radioBtnFromCAD.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox6);
            this.groupBox2.Controls.Add(this.radioBtnToBRL);
            this.groupBox2.Controls.Add(this.pictureBox7);
            this.groupBox2.Controls.Add(this.radioBtnToGBP);
            this.groupBox2.Controls.Add(this.pictureBox8);
            this.groupBox2.Controls.Add(this.radioBtnToEUR);
            this.groupBox2.Controls.Add(this.pictureBox9);
            this.groupBox2.Controls.Add(this.radioBtnToUSD);
            this.groupBox2.Controls.Add(this.pictureBox10);
            this.groupBox2.Controls.Add(this.radioBtnToCAD);
            this.groupBox2.Location = new System.Drawing.Point(292, 30);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(186, 283);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "To";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(90, 225);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(73, 44);
            this.pictureBox6.TabIndex = 28;
            this.pictureBox6.TabStop = false;
            // 
            // radioBtnToBRL
            // 
            this.radioBtnToBRL.AutoSize = true;
            this.radioBtnToBRL.Checked = true;
            this.radioBtnToBRL.Location = new System.Drawing.Point(15, 234);
            this.radioBtnToBRL.Name = "radioBtnToBRL";
            this.radioBtnToBRL.Size = new System.Drawing.Size(66, 24);
            this.radioBtnToBRL.TabIndex = 19;
            this.radioBtnToBRL.TabStop = true;
            this.radioBtnToBRL.Text = "BRL";
            this.radioBtnToBRL.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Location = new System.Drawing.Point(90, 75);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(73, 44);
            this.pictureBox7.TabIndex = 25;
            this.pictureBox7.TabStop = false;
            // 
            // radioBtnToGBP
            // 
            this.radioBtnToGBP.AutoSize = true;
            this.radioBtnToGBP.Location = new System.Drawing.Point(15, 186);
            this.radioBtnToGBP.Name = "radioBtnToGBP";
            this.radioBtnToGBP.Size = new System.Drawing.Size(68, 24);
            this.radioBtnToGBP.TabIndex = 18;
            this.radioBtnToGBP.TabStop = true;
            this.radioBtnToGBP.Text = "GBP";
            this.radioBtnToGBP.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(89, 175);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(73, 44);
            this.pictureBox8.TabIndex = 27;
            this.pictureBox8.TabStop = false;
            // 
            // radioBtnToEUR
            // 
            this.radioBtnToEUR.AutoSize = true;
            this.radioBtnToEUR.Location = new System.Drawing.Point(14, 136);
            this.radioBtnToEUR.Name = "radioBtnToEUR";
            this.radioBtnToEUR.Size = new System.Drawing.Size(69, 24);
            this.radioBtnToEUR.TabIndex = 17;
            this.radioBtnToEUR.TabStop = true;
            this.radioBtnToEUR.Text = "EUR";
            this.radioBtnToEUR.UseVisualStyleBackColor = true;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox9.Location = new System.Drawing.Point(89, 125);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(73, 44);
            this.pictureBox9.TabIndex = 26;
            this.pictureBox9.TabStop = false;
            // 
            // radioBtnToUSD
            // 
            this.radioBtnToUSD.AutoSize = true;
            this.radioBtnToUSD.Location = new System.Drawing.Point(12, 86);
            this.radioBtnToUSD.Name = "radioBtnToUSD";
            this.radioBtnToUSD.Size = new System.Drawing.Size(69, 24);
            this.radioBtnToUSD.TabIndex = 16;
            this.radioBtnToUSD.TabStop = true;
            this.radioBtnToUSD.Text = "USD";
            this.radioBtnToUSD.UseVisualStyleBackColor = true;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox10.BackgroundImage")));
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox10.Location = new System.Drawing.Point(89, 25);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(73, 44);
            this.pictureBox10.TabIndex = 24;
            this.pictureBox10.TabStop = false;
            // 
            // radioBtnToCAD
            // 
            this.radioBtnToCAD.AutoSize = true;
            this.radioBtnToCAD.Location = new System.Drawing.Point(15, 35);
            this.radioBtnToCAD.Name = "radioBtnToCAD";
            this.radioBtnToCAD.Size = new System.Drawing.Size(68, 24);
            this.radioBtnToCAD.TabIndex = 15;
            this.radioBtnToCAD.TabStop = true;
            this.radioBtnToCAD.Text = "CAD";
            this.radioBtnToCAD.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(28, 344);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(130, 26);
            this.textBox1.TabIndex = 21;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(292, 344);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(130, 26);
            this.textBox2.TabIndex = 22;
            this.textBox2.TabStop = false;
            // 
            // MoneyEx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(509, 466);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.btnConvert);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MoneyEx";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MoneyEx - Daniel";
            this.Load += new System.EventHandler(this.MoneyEx_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioBtnFromBRL;
        private System.Windows.Forms.RadioButton radioBtnFromGBP;
        private System.Windows.Forms.RadioButton radioBtnFromEUR;
        private System.Windows.Forms.RadioButton radioBtnFromUSD;
        private System.Windows.Forms.RadioButton radioBtnFromCAD;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioBtnToBRL;
        private System.Windows.Forms.RadioButton radioBtnToGBP;
        private System.Windows.Forms.RadioButton radioBtnToEUR;
        private System.Windows.Forms.RadioButton radioBtnToUSD;
        private System.Windows.Forms.RadioButton radioBtnToCAD;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
    }
}